﻿Install the following nuget packages to your API project :
- SimpleIdentityServer.Uma.Authorization
- SimpleIdentityServer.UmaIntrospection.Authentication